#include "server.hpp"

// void server::login(std::shared_ptr<boost::asio::ip::tcp::socket> socket,int attempts)
// {
//     std::string max_attempts_reached = "Max attempts reached";
//     if (attempts > 2) {
//         socket->write_some(boost::asio::buffer(max_attempts_reached));
//         return;
//     }

//     std::array<char, 256> data;
//     socket->write_some(boost::asio::buffer("110 character limit for the username and 110 for the password"));

//     socket->async_read_some(boost::asio::buffer(data), [this, socket, data, attempts](const boost::system::error_code& error, std::size_t length) mutable {
//         if (!error && length > 0) {
//             try {
//                 std::string received_data(data.data(), length);
//                 auto received_json = nlohmann::json::parse(received_data);

//                 std::string username = received_json["username"];
//                 std::string password = received_json["password"];

//                 int id_user = (*server_sql).get_id_from_username(username);
//                 if (id_user != -1) {
//                     std::string password_in_db = (*server_sql).get_user_password(id_user);
//                     if (password_in_db == password) {
//                         socket->write_some(boost::asio::buffer("Login was successful"));
//                     } else {
//                         socket->write_some(boost::asio::buffer("Incorrect password"));
//                         login(socket, attempts + 1);
//                     }
//                 } else {
//                     socket->write_some(boost::asio::buffer("Incorrect username"));
//                     login(socket, attempts + 1);
//                 }
//             } catch (nlohmann::json::parse_error& e) {
//                 std::cerr << "JSON Parsing Error: " << e.what() << '\n';
//                 socket->lowest_layer().close();
//             }
//             std::fill(std::begin(data), std::end(data), 0); // Clear the buffer
//             login(socket, attempts); // Continue reading next message
//         } else {
//             std::cerr << "Read failed: " << error.message() << '\n';
//             socket->lowest_layer().close();
//         }
//     });

// // }

void server::test_nimic(std::shared_ptr<boost::asio::ip::tcp::socket> socket)
{
    std::cout<<"went well or bad \n";
}

void server::signup(std::shared_ptr<boost::asio::ip::tcp::socket> socket, int attempts, bool was_warning_sent)
{
    if (attempts > 2) {
        socket->write_some(boost::asio::buffer("Max attempts reached"));
        socket->close();
        sockets.erase(std::remove(sockets.begin(), sockets.end(), socket), sockets.end());
        return;
    }

    auto buffer = std::make_shared<std::array<char, 256>>();
    if(!was_warning_sent)
    {
        socket->write_some(boost::asio::buffer("110 character limit for the username and 110 for the password "));
        was_warning_sent=true;
    }
    else{
        int atts = 3 - attempts;
        std::string att = "\nAttempts left: " + std::to_string(atts);
        socket->write_some(boost::asio::buffer(att));
    }   

    buffer->fill(0);
    
    socket->async_read_some(boost::asio::buffer(*buffer),
                                [this, socket, buffer,attempts,was_warning_sent](const boost::system::error_code& error, std::size_t length) 
        {
            if (!error && length > 0) {
                
                std::string received_data(buffer->data(), length);
                std::cout << "Received data: " << received_data << std::endl;
                
                try {
                    
                    auto received_json = nlohmann::json::parse(received_data);

                    std::string password = received_json["password"];
                    std::string username = received_json["username"];
                    
                    std::cout << "\nUsername :\t"<<username <<"\nPassword:\t"<<password<<'\n';

                    int id_user = (*server_sql).get_id_from_username(username);
                    if (id_user == -1) {
                        ///(*server_sql).add_username_and_password(username, password);

                        socket->write_some(boost::asio::buffer("Signup was a success"));
                        test_nimic(socket);
                    }
                    else {
                        socket->write_some(boost::asio::buffer("Username exists,start again"));
                        signup(socket, (attempts +1) ,was_warning_sent);
                    }
                } 
                catch (nlohmann::json::parse_error& e) {
                    socket->write_some(boost::asio::buffer("JSON Parsing Error: " + std::string(e.what()) + "\n"));
                    signup(socket, attempts,was_warning_sent);
                }
               
            }    
            else {
                std::cerr << "Read failed: " << error.message() << '\n';
                socket->close();
                sockets.erase(std::remove(sockets.begin(), sockets.end(), socket), sockets.end());
            }
    });
}
void server::login_or_signup(std::shared_ptr<boost::asio::ip::tcp::socket> socket) {
    std::cout<<"Waiting for data \n";
        auto buffer = std::make_shared<std::array<char, 256>>();

        buffer->fill(0);

        socket->async_read_some(boost::asio::buffer(*buffer),
                                [this, socket, buffer](const boost::system::error_code& error, std::size_t length) 
            {
                if (!error && length > 0) {
                    std::string received_data(buffer->data(), length);
                    std::cout << "Received data: " << received_data << std::endl;
                   try {
                    auto received_json = nlohmann::json::parse(received_data);
                    std::string command = received_json["command"];
                        if (command == "Login") {
                            std::cout << "Login\n";
                        } 
                        else if (command == "Signup") 
                        {
                            std::cout << "Signup\n";
                            signup(socket,0,false);
                        }
                        else 
                        {
                            socket->write_some(boost::asio::buffer("Unknown command"));
                        }
                    }
                    catch (const nlohmann::json::parse_error& e) 
                    {
                        std::cerr << "JSON Parsing Error: " << e.what() << " in data: " << received_data << '\n';
                    }
                } 
                else {
                    std::cerr << "Read failed: " << error.message() << '\n';
                    socket->close();
                    sockets.erase(std::remove(sockets.begin(), sockets.end(), socket), sockets.end());
                }
        });
    }


void server::acceptor_start() {
        auto socket = std::make_shared<boost::asio::ip::tcp::socket>(io_context_);
        acceptor_.async_accept(*socket, [this, socket](const boost::system::error_code& error) {
            if (!error) 
            {
                std::cout << "Successfully accepted a new connection." << std::endl;
                sockets.push_back(socket);
                login_or_signup(socket);

            } 
            else 
            {
                std::cerr << "Failed to accept a new connection: " << error.message() << std::endl;
            }
            acceptor_start();
        });
    }


server::server(boost::asio::io_context& io_context, unsigned short port) : io_context_(io_context), acceptor_(io_context, boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), port))
 {
    this->server_sql = new sql_component ("server.sqlite3");
    if(this->server_sql)
    {
        std::cout<<"SQL Component Started\n";
    }
    
    acceptor_start();
}

void server::test_sql_in_server()
{
    std::cout<<(*server_sql).get_user(1)<<'\n';
    std::cout<<(*server_sql).get_user_password(1)<<'\n';


    std::cout<<(*server_sql).get_user(2)<<'\n';
    std::cout<<(*server_sql).get_user_password(2)<<'\n';


    std::cout<<(*server_sql).get_user(3)<<'\n';
    std::cout<<(*server_sql).get_user_password(3)<<'\n';

    std::cout<<(*server_sql).get_id_from_username("skibidi toilet")<<'\n';
    std::cout<<(*server_sql).get_id_from_username("PAM")<<'\n';
    std::cout<<(*server_sql).get_id_from_username("UNDEFINED")<<'\n';

}

server::~server()
{
    if(this->server_sql!=nullptr)
    {
        delete this->server_sql;
        this->server_sql=nullptr;
    }

}
